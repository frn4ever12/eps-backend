from rest_framework.permissions import BasePermission


# this is the customize permission class.
class IsTeacherUser(BasePermission):
    def has_permission(self, request, view):
        user = request.user
        print(user.is_teacher)
        if user.is_teacher:
            return True
        else:
            return False
