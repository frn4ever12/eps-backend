from rest_framework import serializers
from .models import Tags, Quize, Question, Answer, Exam_Result, Package
from account.models import User


# serializer for the tags model.
class Tage_Serializer(serializers.ModelSerializer):
    class Meta:
        model = Tags
        fields = "__all__"


# serializer for the Quize model.
class Quize_Serializer(serializers.ModelSerializer):
    class Meta:
        model = Quize
        fields = "__all__"
        depth = 1


# serializer for the Quize model.
class Package_Serializer(serializers.ModelSerializer):
    class Meta:
        model = Package
        fields = "__all__"
        depth = 2


# serilaizer for the quize title and id.
class Quize_TnI_Serializer(serializers.ModelSerializer):
    class Meta:
        model = Quize
        fields = ("id", "heading")


# serializer for the question model.
class Question_Serializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = "__all__"
        depth = 1


# serializer for the full question datail with the answer.
class QuestionDetail_Serializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = (
            "id",
            "questions",
            "question_table",
            "question_img",
            "question_audio",
            "answer",
        )
        depth = 1


# serializr for the answer.
class Answer_Serializer(serializers.ModelSerializer):
    total_questions = serializers.SerializerMethodField()

    class Meta:
        model = Answer
        fields = "__all__"

    def get_total_questions(self, instance):
        # Assuming instance.question.quiz gives the related Quiz instance
        quiz = instance.question.quize
        total_questions = quiz.question.count()
        return total_questions


# serializer for the Exam_Result.
class Exam_Result_Serializer(serializers.ModelSerializer):
    quize = Quize_TnI_Serializer(many=True)

    class Meta:
        model = Exam_Result
        fields = "__all__"


# class exam serializer for the indivisual exam result.
class IndivisualExamResult_Serializer(serializers.ModelSerializer):
    quize = serializers.PrimaryKeyRelatedField(read_only=True, many=True)

    class Meta:
        model = Exam_Result
        fields = (
            "result_data",
            "quize",
        )
        # depth = 1


# serializer for the quize heading.
class QuizeHeading_Serializer(serializers.ModelSerializer):
    class Meta:
        model = Quize
        fields = (
            "id",
            "heading",
        )


# serializer for the quize heading.
class QuestionHeading_Serializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = (
            "id",
            "questions",
        )


class TagsHeading_Serializer(serializers.ModelSerializer):
    class Meta:
        model = Tags
        fields = (
            "id",
            "tage_name",
        )


# user serializer for the frontend.
class User_Serializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = (
            "id",
            "exam_id",
            "username",
        )
