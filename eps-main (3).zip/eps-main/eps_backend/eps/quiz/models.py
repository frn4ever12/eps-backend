from django.db import models
from .base import BaseModel
from rest_framework import serializers
import os


# defining the tag model.
class Tags(BaseModel):
    tage_name = models.CharField(
        max_length=20,
        blank=False,
        null=False,
    )

    def __str__(self):
        return self.tage_name


# function to validate the image extension.
def category_image_dir_path(instance, filename):
    fnm = instance.heading
    img = instance.photo
    ext = img.name.split(".")[-1]

    # Validate image extension
    valid_extensions = ["png", "jpg", "jpeg"]
    if ext.lower() not in valid_extensions:
        raise serializers.ValidationError(
            "Extension does not match. It should be of png, jpg, jpeg"
        )

    # Define the directory path for event photos
    Quize_photo_directory = "Quize_Photos"

    # Construct the file path within the event photos directory
    filename = f"{fnm}.{ext}"
    return os.path.join(Quize_photo_directory, filename)


# creating the model for the Quize.
class Quize(BaseModel):
    photo = models.FileField(
        upload_to=category_image_dir_path,
        blank=True,
        null=True,
    )
    heading = models.CharField(
        max_length=200,
        blank=False,
        null=False,
    )
    sub_heading = models.CharField(
        max_length=200,
        blank=True,
        null=True,
    )
    price = models.PositiveBigIntegerField(
        blank=True,
        null=True,
    )
    tags = models.ManyToManyField(Tags, blank=True)
    time_duration = models.TimeField(
        blank=False,
        null=False,
    )

    def __str__(self):
        return self.heading


# defining the model for the packages.
class Package(BaseModel):
    heading = models.CharField(max_length=200, blank=False, null=False)
    sub_heading = models.CharField(
        max_length=200,
        blank=True,
        null=True,
    )
    price = models.PositiveBigIntegerField(blank=False, null=False)
    quize = models.ManyToManyField(
        Quize,
        related_name="package",
        blank=False,
        null=False,
    )
    tags = models.ManyToManyField(
        Tags,
        blank=True,
        null=True,
        related_name="package_tags",
    )

    def __str__(self):
        return self.heading


# function to validate the image extension.
def category_image_dir_path(instance, filename):
    fnm = instance.questions
    img = instance.question_img
    ext = img.name.split(".")[-1]
    print("==============================", ext)

    # Validate image extension
    valid_extensions = ["png", "jpg", "jpeg"]
    if ext.lower() not in valid_extensions:
        raise serializers.ValidationError(
            "Extension does not match. It should be of png, jpg, jpeg"
        )

    # Define the directory path for event photos
    question_photos_directory = "Question_Photos"

    # Construct the file path within the event photos directory
    filename = f"{fnm}.{ext}"
    return os.path.join(question_photos_directory, filename)


# creating the model for the questions.
class Question(BaseModel):
    quize = models.ForeignKey(
        Quize,
        on_delete=models.CASCADE,
        related_name="question",
        blank=False,
        null=False,
    )
    questions = models.TextField()
    question_table = models.TextField(blank=True, null=True)
    question_img = models.FileField(
        upload_to=category_image_dir_path,
        null=True,
        blank=True,
    )
    question_audio = models.FileField(
        upload_to="audio/",
        null=True,
        blank=True,
    )

    def __str__(self):
        return self.questions


# function to validate the image extension.
def category_image_dir_path1(instance, filename):
    fnm = instance.question
    img = instance.question_img
    ext = img.name.split(".")[-1]

    # Validate image extension
    valid_extensions = ["png", "jpg", "jpeg"]
    if ext.lower() not in valid_extensions:
        raise serializers.ValidationError(
            "Extension does not match. It should be of png, jpg, jpeg"
        )

    # Define the directory path for event photos
    question_photos_directory = "Question_Photos"

    # Construct the file path within the event photos directory
    filename = f"{fnm}.{ext}"
    return os.path.join(question_photos_directory, filename)


# creating the model for the answer.
class Answer(BaseModel):
    question = models.ForeignKey(
        Question,
        on_delete=models.CASCADE,
        related_name="answer",
        null=True,
        blank=True,
    )
    # text answer.
    option1 = models.CharField(max_length=50, blank=True, null=True)
    option2 = models.CharField(max_length=50, blank=True, null=True)
    option3 = models.CharField(max_length=50, blank=True, null=True)
    option4 = models.CharField(max_length=50, blank=True, null=True)
    # image answer.
    option_image1 = models.FileField(
        upload_to="answer_image/",
        blank=True,
        null=True,
    )
    option_image2 = models.FileField(
        upload_to="answer_image/",
        blank=True,
        null=True,
    )
    option_image3 = models.FileField(
        upload_to="answer_image/",
        blank=True,
        null=True,
    )
    option_image4 = models.FileField(
        upload_to="answer_image/",
        blank=True,
        null=True,
    )
    # audio answer.
    option_audio1 = models.FileField(
        upload_to="answer_audio/",
        blank=True,
        null=True,
    )
    option_audio2 = models.FileField(
        upload_to="answer_audio/",
        blank=True,
        null=True,
    )
    option_audio3 = models.FileField(
        upload_to="answer_audio/",
        blank=True,
        null=True,
    )
    option_audio4 = models.FileField(
        upload_to="answer_audio/",
        blank=True,
        null=True,
    )

    # Field to specify the correct answer
    CORRECT_ANSWER_CHOICES = (
        ("option1", "Option 1"),
        ("option2", "Option 2"),
        ("option3", "Option 3"),
        ("option4", "Option 4"),
        ("option_image1", "Image Option 1"),
        ("option_image2", "Image Option 2"),
        ("option_image3", "Image Option 3"),
        ("option_image4", "Image Option 4"),
        ("option_audio1", "Audio Option 1"),
        ("option_audio2", "Audio Option 2"),
        ("option_audio3", "Audio Option 3"),
        ("option_audio4", "Audio Option 4"),
    )
    correct_answer = models.CharField(
        max_length=20,
        choices=CORRECT_ANSWER_CHOICES,
        blank=False,
        null=False,
    )

    def __str__(self):
        return f"Answer to {self.question}"


# creating the model for the exam.
class Exam_Result(models.Model):
    user = models.CharField(max_length=30, blank=True, null=True)
    quize = models.ManyToManyField(Quize, related_name="exam_results")
    total_questions = models.IntegerField()
    correct_answers = models.IntegerField()
    solved = models.IntegerField()
    unsolved = models.IntegerField()
    score = models.FloatField()
    result = models.CharField(max_length=10, blank=True, null=True)
    result_data = models.JSONField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Quiz Submission Result - {self.id}"
