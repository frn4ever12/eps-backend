from django.urls import path
from . import views

urlpatterns = [
    # Tags Model.
    path(
        "tags/create/",
        views.TagsCreateApiView.as_view(),
        name="tags create path",
    ),
    path(
        "tags/list/",
        views.TagsListApiView.as_view(),
        name="tags list path",
    ),
    path(
        "tags/search/",
        views.TagsSearchApiView.as_view(),
        name="tags search path only for the admin",
    ),
    path(
        "tags/delete/<int:pk>/",
        views.TagsDeleteApiView.as_view(),
        name="tags delete path only for the admin",
    ),
    path(
        "tags/update/<int:pk>/",
        views.TagsUpdateApiView.as_view(),
        name="tags update path only for the admin",
    ),
    # Quize.
    path(
        "quize/create/",
        views.QuizeCreateApiView.as_view(),
        name="quize create path",
    ),
    path(
        "quize/list/",
        views.QuizeListApiView.as_view(),
        name="quize list path",
    ),
    path(
        "quize/search/",
        views.QuizeSearchApiView.as_view(),
        name="quize search path",
    ),
    path(
        "quize/delete/<int:pk>/",
        views.QuizeDeleteApiView.as_view(),
        name="quize delete path",
    ),
    path(
        "quize/update/<int:pk>/",
        views.QuizeUpdateApiView.as_view(),
        name="quize update path",
    ),
    path(
        "quize/<int:pk>/",
        views.QuizeDetailApiView.as_view(),
        name="quize detail path",
    ),
    # Packages.
    path(
        "package/create/",
        views.PackageCreateApiView.as_view(),
        name="package create path",
    ),
    path(
        "package/list/",
        views.PackageListApiView.as_view(),
        name="package list path",
    ),
    path(
        "package/search/",
        views.PackageSearchApiView.as_view(),
        name="package search path",
    ),
    path(
        "package/delete/<int:pk>/",
        views.PackageDeleteApiView.as_view(),
        name="package delete path",
    ),
    path(
        "package/update/<int:pk>/",
        views.PackageUpdateApiView.as_view(),
        name="package update path",
    ),
    # Question.
    path(
        "question/create/",
        views.QuestionCreateApiView.as_view(),
        name="question create path",
    ),
    path(
        "question/delete/<int:pk>/",
        views.QuestionDeleteApiView.as_view(),
        name="question delete path",
    ),
    path(
        "question/update/<int:pk>/",
        views.QuestionUpdateApiView.as_view(),
        name="question update path",
    ),
    path(
        "question/list/<int:pk>/",
        views.QuestionListApiView.as_view(),
        name="question list for the particular quize selected",
    ),
    path(
        "question/indivisual/list/<int:pk>/",
        views.IndivisualQuestionApiView.as_view(),
        name="path to ge the indivisual question list",
    ),
    # Answer.
    path(
        "answer/create/<int:pk>/",
        views.AnswerCreateApiView.as_view(),
        name="answer create path",
    ),
    path(
        "answer/delete/<int:pk>/",
        views.AnswerDeleteApiView.as_view(),
        name="answer delete path",
    ),
    path(
        "answer/update/<int:pk>/",
        views.AnswerUpdateApiView.as_view(),
        name="answer update path",
    ),
    path(
        "answer/check/",
        views.QuizSubmissionAPIView.as_view(),
        name="answer check path",
    ),
    path(
        "answer/check1/<str:action>/",
        views.QuizSubmissionAPIView1.as_view(),
        name="answer check path2",
    ),
    path(
        "user/result/",
        views.ResultDispalyApiView.as_view(),
        name="user result path",
    ),
    path(
        "all/result/",
        views.ResultAllApiView.as_view(),
        name="all result path for the admin",
    ),
    path(
        "result/search/",
        views.ResultSearchApiView.as_view(),
        name="result search path",
    ),
    path(
        "result/print/",
        views.ResultPrintableApiView.as_view(),
        name="result print path",
    ),
    path(
        "indivisual/result/<int:pk>/",
        views.IndivisualExamResultApiView.as_view(),
        name="indivisual result path",
    ),
    path(
        "available/quize/",
        views.AvailableExamApiView.as_view(),
        name="available quize path",
    ),
    path(
        "quize/",
        views.QuizeHeadingListApiView.as_view(),
        name="quize list for the admin",
    ),
    path(
        "question/",
        views.QuestionHeadingListApiView.as_view(),
        name="question list for the admin",
    ),
    path(
        "tags/",
        views.TagsHeadingListApiView.as_view(),
        name="tags list for the admin",
    ),
    path(
        "question/answer/create/",
        views.QuestionAndAnswerCreateApiView.as_view(),
        name="path to create the question and the answer throught the same api.",
    ),
    path(
        "question/answer/update/<int:pk>/",
        views.QuestionAndAnswerUpdateApiView.as_view(),
        name="path to update the question and the answer throught the same api.",
    ),
]
