from django.shortcuts import render
from eps.render import UserRenderer
from rest_framework.views import APIView
from rest_framework import generics, permissions, status
from .models import Tags, Quize, Question, Answer, Exam_Result, Package
from account.models import User
from rest_framework.response import Response
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from rest_framework.filters import SearchFilter
from .serializer import (
    Tage_Serializer,
    Quize_Serializer,
    Question_Serializer,
    QuestionDetail_Serializer,
    Answer_Serializer,
    Exam_Result_Serializer,
    Package_Serializer,
    QuizeHeading_Serializer,
    QuestionHeading_Serializer,
    TagsHeading_Serializer,
    User_Serializer,
    IndivisualExamResult_Serializer,
)
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from django.contrib.sessions.models import Session
from django.utils import timezone
from django.contrib.auth import get_user
from django.utils.dateparse import parse_date
from django.utils.timezone import make_aware
import json


# Tags
# Tags create view.
class TagsCreateApiView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]

    def post(self, request, *args, **kwargs):
        serializer = Tage_Serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.validated_data["created_by"] = request.user.username
            serializer.validated_data["updated_by"] = "None"
            serializer.save()
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Tags list view.
class TagsListApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    queryset = Tags.objects.all().order_by("-id")
    serializer_class = Tage_Serializer


# Tags search for the admin only.
class TagsSearchApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    queryset = Tags.objects.all().order_by("-id")
    serializer_class = Tage_Serializer
    filter_backends = [SearchFilter]
    search_fields = ["tage_name"]


# Tags delete view.
class TagsDeleteApiView(generics.DestroyAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    queryset = Tags.objects.all().order_by("-id")
    serializer_class = Tage_Serializer


# Tags update view.
class TagsUpdateApiView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]

    def put(self, request, id, *args, **kwargs):
        try:
            tags_data = Tags.objects.get(id=id)
        except Tags.DoesNotExist:
            return Response({"msg": f"Tag with id {id} doesnot found in the database"})
        serializer = Tage_Serializer(tags_data, data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.validated_data["updated_by"] = request.user.username
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Quize
# quize create view.
class QuizeCreateApiView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]

    def post(self, request, *args, **kwargs):
        serializer = Quize_Serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.validated_data["created_by"] = request.user.username
            serializer.validated_data["updated_by"] = "None"
            # Parse tags from JSON string to list of integers
            tags_data = request.data.get("tags", "[]")
            if isinstance(tags_data, str):
                tags_data = json.loads(tags_data)
            quiz_instance = serializer.save()
            print(tags_data)
            for tag_id in tags_data:
                try:
                    tag = Tags.objects.get(id=tag_id)
                    print(tag)
                    quiz_instance.tags.add(tag)
                except Tags.DoesNotExist:
                    return Response(
                        {"error": f"Tag with id {tag_id} does not exist."},
                        status=status.HTTP_400_BAD_REQUEST,
                    )
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# quize list view.
class QuizeListApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    queryset = Quize.objects.all().order_by("-id")
    serializer_class = Quize_Serializer


# quize search view.
class QuizeSearchApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    queryset = Quize.objects.all().order_by("-id")
    serializer_class = Quize_Serializer
    filter_backends = [SearchFilter]
    search_fields = ["heading"]


# quize delete view.
class QuizeDeleteApiView(generics.DestroyAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    queryset = Quize.objects.all()
    serializer_class = Quize_Serializer


# quize update view.
class QuizeUpdateApiView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]

    def put(self, request, pk, *args, **kwargs):
        try:
            quize_data = Quize.objects.get(id=pk)
            print(quize_data)
        except Quize.DoesNotExist:
            return Response(
                {"msg": f"quize with id {pk} is not present in our database"},
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = Quize_Serializer(quize_data, data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.validated_data["updated_by"] = request.user.username
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# available quize list.
class AvailableExamApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    serializer_class = Quize_Serializer

    def get_queryset(self):
        return Quize.objects.filter(tags=5)


# quize indivisual detial.
class QuizeDetailApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    serializer_class = Quize_Serializer

    def get_queryset(self):
        id = self.kwargs.get("pk")
        return Quize.objects.filter(id=id)


# Package
# package create view.
class PackageCreateApiView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]

    def post(self, request, *args, **kwargs):
        serializer = Package_Serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.validated_data["created_by"] = request.user.username
            serializer.validated_data["updated_by"] = "None"
            tags_data = request.data.get("tags", [])
            quize_data = request.data.get("quize", [])
            quiz_instance = serializer.save()
            for tag_id in tags_data:
                tag = Tags.objects.get(id=tag_id)
                quiz_instance.tags.add(tag)
            for quize_id in quize_data:
                quize = Quize.objects.get(id=quize_id)
                quiz_instance.quize.add(quize)
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# package list view.
class PackageListApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    queryset = Package.objects.all().order_by("-id")
    serializer_class = Package_Serializer


# package search view.
class PackageSearchApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    queryset = Package.objects.all().order_by("-id")
    serializer_class = Package_Serializer
    filter_backends = [SearchFilter]
    search_fields = ["heading"]


# package delete view.
class PackageDeleteApiView(generics.DestroyAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    queryset = Package.objects.all()
    serializer_class = Package_Serializer


# package update view.
class PackageUpdateApiView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]

    def put(self, request, id, *args, **kwargs):
        try:
            package_data = Package.objects.get(id=id)
        except Package.DoesNotExist:
            return Response(
                {"msg": f"quize with id {id} is not present in our database"},
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = Package_Serializer(package_data, data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.validated_data["updated_by"] = request.user.username
            serializer.save()
            return Response(serializer.data, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Question.
# question create path.
class QuestionCreateApiView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]

    def post(self, request, *args, **kwargs):
        serializer = Question_Serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.validated_data["created_by"] = request.user.username
            serializer.save()
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# question delete view.
class QuestionDeleteApiView(generics.DestroyAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    queryset = Question.objects.all()
    serializer_class = Question_Serializer


# question update view.
class QuestionUpdateApiView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]

    def put(self, request, pk, *args, **kwargs):
        try:
            question_data = Question.objects.get(id=pk)
            print(question_data)
        except Question.DoesNotExist:
            return Response(
                {"msg": f"question with id {pk} is not present."},
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = Question_Serializer(question_data, data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.validated_data["updated_by"] = request.user.username
            serializer.save()
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# question list according to the quize selected.
class QuestionListApiView(APIView):
    renderer_classes = [UserRenderer]

    def get(self, request, pk, *args, **kwargs):
        questions = Question.objects.filter(quize__id=pk).order_by("?")[:40]
        serializer = QuestionDetail_Serializer(questions, many=True)
        return Response(
            serializer.data,
        )


# indivisual Question list View.
class IndivisualQuestionApiView(APIView):
    renderer_classes = [UserRenderer]

    def get(self, request, pk, *args, **kwargs):
        questions = Question.objects.filter(id=pk)
        serializer = QuestionDetail_Serializer(questions, many=True)
        return Response(
            serializer.data,
        )


# Answer.
# answer create path.
class AnswerCreateApiView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]

    def post(self, request, pk, *args, **kwargs):
        question_data = Question.objects.get(id=pk)
        serializer = Answer_Serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.validated_data["created_by"] = request.user.username
            serializer.validated_data["question"] = question_data
            serializer.save()
            print(serializer.data)
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# answer delete view.
class AnswerDeleteApiView(generics.DestroyAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    queryset = Answer.objects.all()
    serializer_class = Answer_Serializer


# answer update view.
class AnswerUpdateApiView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]

    def put(self, request, pk, *args, **kwargs):
        try:
            answer_data = Answer.objects.get(id=pk)
            print(answer_data)
        except Question.DoesNotExist:
            return Response(
                {"msg": f"answer with id {pk} is not present."},
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = Answer_Serializer(answer_data, data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.validated_data["updated_by"] = request.user.username
            serializer.save()
            return Response(
                serializer.data,
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# vlaidate answer from the front-end.
class QuizSubmissionAPIView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, *args, **kwargs):
        submitted_answers = request.data.get("answers", [])
        print(submitted_answers)
        print(type(submitted_answers))
        quiz_id = request.data.get("quiz_id")
        quiz = get_object_or_404(Quize, id=quiz_id)
        print(quiz)
        # Serialize the quiz object
        quiz_serializer = QuizeHeading_Serializer(quiz)
        serialized_quiz_data = quiz_serializer.data
        print(serialized_quiz_data)
        questions = quiz.question.all()
        total_questions = questions.count()
        correct_answers = 0
        solved = 0
        unsolved = 0
        result = []

        for answer_data in submitted_answers:
            question_id = answer_data.get("question_id")
            selected_option = answer_data.get("selected_option")
            print(type(selected_option))
            question = get_object_or_404(Question, id=question_id)
            corr_answers = Answer.objects.filter(question=question)
            for answer in corr_answers:
                correct_option = answer.correct_answer

            if selected_option is None:
                unsolved += 1
                result.append(
                    {
                        "question_id": question_id,
                        "unsolved": True,
                        "correct_answer": correct_option,
                        "selected_option": selected_option,
                    }
                )
            else:
                solved += 1
                if selected_option == correct_option:
                    correct_answers += 1
                    result.append(
                        {
                            "question_id": question_id,
                            "correct": True,
                            "correct_answer": correct_option,
                            "selected_option": selected_option,
                        }
                    )
                else:
                    result.append(
                        {
                            "question_id": question_id,
                            "correct": False,
                            "correct_answer": correct_option,
                            "selected_option": selected_option,
                        }
                    )

        # Calculate score
        score = (correct_answers / total_questions) * 100
        if score >= 40:
            user_resutl = "pass"
        else:
            user_resutl = "fail"

        print(result)
        user = request.user.username
        user_data = User.objects.get(username=user)
        user_serilaizer = User_Serializer(user_data)
        user_serilaizer_data = user_serilaizer.data

        exam_result = Exam_Result(
            user=user,
            total_questions=total_questions,
            correct_answers=correct_answers,
            solved=solved,
            unsolved=unsolved,
            result=user_resutl,
            score=score,
            result_data=result,
        )
        exam_result.save()
        exam_result.quize.add(quiz)

        return Response(
            {
                "user": user_serilaizer_data,
                "exam": serialized_quiz_data,
                "total_questions": total_questions,
                "correct_answers": correct_answers,
                "sloved": solved,
                "unsolved": unsolved,
                "result": result,
                "score": score,
                "user_result": user_resutl,
            }
        )


class QuizSubmissionAPIView1(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, *args, **kwargs):
        action = kwargs["action"]
        user = request.user

        if action == "next":
            submitted_answers = request.session.get(f"submitted_answers_{user.pk}", [])
            quiz_id = request.data.get("quiz_id")
            new_answers = request.data.get("answers", [])
            updated = False

            solved = request.session.get(f"solved_{user.pk}", 0)
            unsolved = request.session.get(f"unsolved_{user.pk}", 0)

            for answer_set in submitted_answers:
                if answer_set.get("quiz_id") == quiz_id:
                    for new_answer in new_answers:
                        question_id = new_answer.get("question_id")
                        for existing_answer in answer_set["answers"]:
                            if existing_answer["question_id"] == question_id:
                                existing_option = existing_answer["selected_option"]
                                new_option = new_answer["selected_option"]
                                if existing_option != "None" and new_option == "None":
                                    solved -= 1
                                    unsolved += 1
                                    updated = True
                                elif existing_option == "None" and new_option != "None":
                                    solved += 1
                                    unsolved -= 1
                                    updated = True
                                existing_answer["selected_option"] = new_option
                                break
                        if updated:
                            break
                    else:
                        for answer in new_answers:
                            new_option = answer["selected_option"]
                            if new_option == "None":
                                unsolved += 1
                            else:
                                solved += 1
                        answer_set["answers"].extend(new_answers)
                    break
            else:
                for answer in new_answers:
                    new_option = answer["selected_option"]
                    if new_option == "None":
                        unsolved += 1
                    else:
                        solved += 1
                submitted_answers.append({"quiz_id": quiz_id, "answers": new_answers})

            request.session[f"submitted_answers_{user.pk}"] = submitted_answers
            request.session[f"quiz_id_{user.pk}"] = quiz_id
            request.session[f"solved_{user.pk}"] = solved
            request.session[f"unsolved_{user.pk}"] = unsolved
            request.session.save()

            return Response(
                {
                    "message": "Next action processed successfully",
                    "solved": solved,
                    "unsolved": unsolved,
                    "solved_question": submitted_answers,
                }
            )

        elif action == "submit":
            submitted_answers = request.session.get(f"submitted_answers_{user.pk}", [])
            quiz_id = request.session.get(f"quiz_id_{user.pk}")
            quiz = get_object_or_404(Quize, id=quiz_id)
            time_duration = quiz.time_duration
            questions = quiz.question.all()
            total_questions = questions.count()
            correct_answers = 0
            solved = 0
            unsolved = 0
            result = []

            for answer_data in submitted_answers:
                answers = answer_data.get("answers", [])
                for answer in answers:
                    question_id = answer.get("question_id")
                    selected_option = answer.get("selected_option")
                    question = get_object_or_404(Question, id=question_id)
                    corr_answers = Answer.objects.filter(question=question)
                    correct_option = None
                    for ans in corr_answers:
                        correct_option = ans.correct_answer

                    if selected_option == "None":
                        unsolved += 1
                        result.append(
                            {
                                "question_id": question_id,
                                "unsolved": True,
                                "correct_answer": correct_option,
                            }
                        )
                    else:
                        if selected_option == correct_option:
                            correct_answers += 1
                            result.append(
                                {
                                    "question_id": question_id,
                                    "correct": True,
                                    "correct_answer": correct_option,
                                }
                            )
                        else:
                            result.append(
                                {
                                    "question_id": question_id,
                                    "correct": False,
                                    "correct_answer": correct_option,
                                }
                            )
                        solved += 1

            score = (correct_answers / total_questions) * 100
            user_result = "pass" if score >= 40 else "fail"

            user_name = user.username
            exam_result = Exam_Result(
                user=user_name,
                total_questions=total_questions,
                correct_answers=correct_answers,
                solved=solved,
                unsolved=unsolved,
                result=user_result,
                score=score,
                result_data=result,
            )
            exam_result.save()
            exam_result.quiz.add(quiz)

            request.session.pop(f"submitted_answers_{user.pk}", None)
            request.session.pop(f"quiz_id_{user.pk}", None)
            request.session.pop(f"solved_{user.pk}", None)
            request.session.pop(f"unsolved_{user.pk}", None)
            request.session.save()

            return Response(
                {
                    "total_questions": total_questions,
                    "correct_answers": correct_answers,
                    "solved": solved,
                    "unsolved": unsolved,
                    "result": result,
                    "score": score,
                }
            )

        else:
            return Response(
                {"error": "Invalid action"}, status=status.HTTP_400_BAD_REQUEST
            )


# result display of the login user.
class ResultDispalyApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    serializer_class = Exam_Result_Serializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        print(user.username)
        return Exam_Result.objects.filter(user=user.username).order_by("-id")


# all result list based on the heading/quize.
class ResultAllApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    serializer_class = Exam_Result_Serializer

    def get_queryset(self):
        result = self.request.query_params.get("result")
        date_start = self.request.query_params.get("date_start")
        date_ended = self.request.query_params.get("date_ended")
        print(result)
        print(date_start)
        print(date_ended)

        # Case: result is not None
        if result is not None:
            try:
                quiz_data = Quize.objects.get(id=result)
            except Quize.DoesNotExist:
                return (
                    Exam_Result.objects.none()
                )  # Return an empty queryset if the quiz does not exist

            # Subcase: result is not None, start_date and end_date are both provided
            if date_start and date_ended:
                return Exam_Result.objects.filter(
                    quize=quiz_data, created_at__date__range=(date_start, date_ended)
                )
            # Subcase: result is not None, only start_date is provided
            elif date_start:
                return Exam_Result.objects.filter(
                    quize=quiz_data, created_at__date=date_start
                )
            # Subcase: result is not None, no date filters are provided
            else:
                return Exam_Result.objects.filter(quize=quiz_data)

        # Case: result is None
        else:
            # Subcase: result is None, start_date and end_date are both provided
            if date_start and date_ended:
                return Exam_Result.objects.filter(
                    created_at__date__range=(date_start, date_ended)
                )
            # Subcase: result is None, only start_date is provided
            elif date_start:
                return Exam_Result.objects.filter(created_at__date=date_start)
            # Subcase: result is None, no date filters are provided
            else:
                return Exam_Result.objects.all()


# result search view.
class ResultSearchApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    queryset = Exam_Result.objects.all()
    permission_classes = [permissions.IsAdminUser]
    serializer_class = Exam_Result_Serializer
    filter_backends = [SearchFilter]
    search_fields = ["user"]


# printable result form view.
class ResultPrintableApiView(APIView):
    renderer_classes = [UserRenderer]

    def get(self, request, *args, **kwargs):
        quize_id = request.data.get("quiz_id")
        start_date = request.data.get("start_date")
        end_date = request.data.get("end_date")

        if quize_id == "all":
            queryset = Exam_Result.objects.all(created_at__range=[start_date, end_date])
        else:
            queryset = Exam_Result.objects.filter(
                quize=quize_id,
                created_at__range=[start_date, end_date],
            )

        serializer = Exam_Result_Serializer(queryset, many=True)
        data = serializer.data
        print(data)

        # now creatig the pdf files.
        response = HttpResponse(content_type="application/pdf")
        response["Content-Disposition"] = 'attachment; filename="quiz_report.pdf"'

        # Create a new PDF document
        pdf_buffer = response
        doc = SimpleDocTemplate(pdf_buffer, pagesize=letter)
        elements = []
        title_style = ParagraphStyle(name="TitleStyle", fontSize=16, alignment=1)
        title = Paragraph("Quiz Report", title_style)
        elements.append(title)

        elements.append(Spacer(1, 20))

        # Data for the table
        table_data = [
            [
                "Id",
                "User",
                "Quize",
                "Total Questions",
                "Correct Answers",
                "Solved",
                "Unsolved",
                "Score",
                "Result",
            ]
        ]

        # Populate table data from the 'data' list
        for item in data:
            quize_heading = item["Quize"][0]["heading"] if item["quize"] else ""
            table_data.append(
                [
                    item["id"],
                    item["user"],
                    quize_heading,
                    item["total_questions"],
                    item["correct_answers"],
                    item["solved"],
                    item["unsolved"],
                    item["score"],
                    item["result"],
                ]
            )

        # Create the table
        table = Table(table_data)
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.lightgrey),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
                    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("BOTTOMPADDING", (0, 0), (-1, 0), 12),
                    ("BACKGROUND", (0, 1), (-1, -1), colors.white),
                    ("GRID", (0, 0), (-1, -1), 1, colors.black),
                ]
            )
        )

        # Add table to elements list
        elements.append(table)

        # Build the PDF document
        doc.build(elements)

        return response


# result data for the user based on the id.
class IndivisualExamResultApiView(generics.ListAPIView):
    enderer_classes = [UserRenderer]
    serializer_class = IndivisualExamResult_Serializer

    def get_queryset(self):
        pk = self.kwargs.get("pk")
        return Exam_Result.objects.filter(id=pk)


# this is the quize list heading and the id for the frontend.
class QuizeHeadingListApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    # permission_classes = [permissions.IsAdminUser]
    queryset = Quize.objects.all().order_by("-id")
    serializer_class = QuizeHeading_Serializer


# this is the question list heading and the id for the frontend.
class QuestionHeadingListApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    # permission_classes = [permissions.IsAdminUser]
    queryset = Question.objects.all().order_by("-id")
    serializer_class = QuestionHeading_Serializer


# this is the tag list heading and the id for the frontend.
class TagsHeadingListApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    # permission_classes = [permissions.IsAdminUser]
    queryset = Tags.objects.all().order_by("-id")
    serializer_class = TagsHeading_Serializer


# view for the question create and the answer creat in the same api.
class QuestionAndAnswerCreateApiView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]

    def post(self, request, *args, **kwargs):
        data = request.data
        print(data)

        # Extract the question data
        question_data = {
            "questions": data.get("questions"),
            "quize": data.get("quize"),
            "question_table": data.get("question_table"),
            "question_img": data.get("question_img"),
            "question_audio": data.get("question_audio"),
        }

        # Extract the answer data
        answer_data = {
            "quize": data.get("quize"),
            "question_table": data.get("question_table"),
            "question_img": data.get("question_img"),
            "question_audio": data.get("question_audio"),
            "option1": data.get("option1"),
            "option2": data.get("option2"),
            "option3": data.get("option3"),
            "option4": data.get("option4"),
            "option_image1": data.get("option_image1"),
            "option_image2": data.get("option_image2"),
            "option_image3": data.get("option_image3"),
            "option_image4": data.get("option_image4"),
            "option_audio1": data.get("option_audio1"),
            "option_audio2": data.get("option_audio2"),
            "option_audio3": data.get("option_audio3"),
            "option_audio4": data.get("option_audio4"),
            "correct_answer": data.get("correct_answer"),
        }

        question_serializer = Question_Serializer(data=question_data)
        answer_serializer = Answer_Serializer(data=answer_data)

        if question_serializer.is_valid(
            raise_exception=True
        ) and answer_serializer.is_valid(raise_exception=True):
            question_serializer.validated_data["created_by"] = request.user.username
            answer_serializer.validated_data["created_by"] = request.user.username

            question_instance = question_serializer.save()
            answer_serializer.validated_data["question"] = question_instance
            answer_serializer.save()
            data = {
                "question": question_serializer.data,
                "answer": answer_serializer.data,
            }
            return Response(data, status=status.HTTP_201_CREATED)
        return Response(
            {
                "question_errors": question_serializer.errors,
                "answer_errors": answer_serializer.errors,
            },
            status=status.HTTP_400_BAD_REQUEST,
        )


# view for the question and the answer for the update.
class QuestionAndAnswerUpdateApiView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]

    def put(self, request, pk, *args, **kwargs):
        # Retrieve the question instance
        question_instance = get_object_or_404(Question, id=pk)

        # Retrieve the associated answer instance
        try:
            answer_instance = Answer.objects.get(question=question_instance)
        except Answer.DoesNotExist:
            return Response(
                {"msg": f"Answer associated with question id {pk} does not exist."},
                status=status.HTTP_404_NOT_FOUND,
            )

        # Extract the question data
        question_data = {
            "questions": request.data.get("questions"),
            "quize": request.data.get("quize"),
            "question_table": request.data.get("question_table"),
            "question_img": request.data.get("question_img"),
            "question_audio": request.data.get("question_audio"),
        }

        # Extract the answer data
        answer_data = {
            "option1": request.data.get("option1"),
            "option2": request.data.get("option2"),
            "option3": request.data.get("option3"),
            "option4": request.data.get("option4"),
            "option_image1": request.data.get("option_image1"),
            "option_image2": request.data.get("option_image2"),
            "option_image3": request.data.get("option_image3"),
            "option_image4": request.data.get("option_image4"),
            "option_audio1": request.data.get("option_audio1"),
            "option_audio2": request.data.get("option_audio2"),
            "option_audio3": request.data.get("option_audio3"),
            "option_audio4": request.data.get("option_audio4"),
            "correct_answer": request.data.get("correct_answer"),
        }

        # Initialize serializers with existing instances and new data
        question_serializer = Question_Serializer(
            question_instance, data=question_data, partial=True
        )
        answer_serializer = Answer_Serializer(
            answer_instance, data=answer_data, partial=True
        )

        # Validate and save the serializers
        if question_serializer.is_valid(
            raise_exception=True
        ) and answer_serializer.is_valid(raise_exception=True):
            question_serializer.validated_data["updated_by"] = request.user.username
            answer_serializer.validated_data["updated_by"] = request.user.username

            question_serializer.save()
            answer_serializer.save()

            data = {
                "question": question_serializer.data,
                "answer": answer_serializer.data,
            }
            return Response(data, status=status.HTTP_200_OK)

        return Response(
            {
                "question_errors": question_serializer.errors,
                "answer_errors": answer_serializer.errors,
            },
            status=status.HTTP_400_BAD_REQUEST,
        )
