from django.contrib import admin
from .models import Tags, Quize, Question, Answer, Exam_Result, Package


# Tags model registrations.
class Tags_Admin(admin.ModelAdmin):
    list_display = ("id", "tage_name", "created_by", "updated_by")


admin.site.register(Tags, Tags_Admin)


# Quize model registration.
class Quize_Admin(admin.ModelAdmin):
    list_display = (
        "id",
        "photo",
        "created_by",
        "updated_by",
        "heading",
        "sub_heading",
        "price",
        "time_duration",
    )


admin.site.register(Quize, Quize_Admin)


# Question model registration.
class Question_Admin(admin.ModelAdmin):
    list_display = (
        "id",
        "quize",
        "questions",
        "question_table",
        "question_img",
        "question_audio",
    )


admin.site.register(Question, Question_Admin)

# Answer model registration.
# class Answer_Admin(admin.ModelAdmin):

admin.site.register(Answer)

admin.site.register(Exam_Result)

admin.site.register(Package)
