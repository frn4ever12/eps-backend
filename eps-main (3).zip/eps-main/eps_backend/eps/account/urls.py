from django.urls import path
from . import views

urlpatterns = [
    # USER ACCOUNT MANAGEMENT PATH.
    path(
        "register/",
        views.UserRegistrationView.as_view(),
        name="user registration path",
    ),
    path(
        "login/",
        views.UserLoginView.as_view(),
        name="user login path",
    ),
    path(
        "login/user/profile/",
        views.UserProfileView.as_view(),
        name="login user profile path",
    ),
    path(
        "login/user/profile/update/",
        views.UserProfileUpdateView.as_view(),
        name="login user profile update",
    ),
    path(
        "password/change/",
        views.UserPasswordChangeView.as_view(),
        name="user password change path",
    ),
    path(
        "send/reset/password/email/",
        views.SendPassowrdEmailView.as_view(),
        name="password change email path",
    ),
    path(
        "reset/password/<uid>/<token>/",
        views.UserPasswordResetView.as_view(),
        name="user e-password change path",
    ),
    path(
        "google/",
        views.GoogleSignInApiView.as_view(),
        name="google conntction path",
    ),
    path(
        "users/<str:name>/",
        views.UserApiView.as_view(),
        name="total user path",
    ),
    path(
        "user/delete/<int:pk>/",
        views.UserDeleteApiView.as_view(),
        name="path to delete the user for the admin.",
    ),
]
