from django.shortcuts import render
from rest_framework_simplejwt.tokens import RefreshToken
from eps.render import UserRenderer
from rest_framework.views import APIView
from rest_framework.generics import GenericAPIView
from .serializer import (
    UserRegistration_Serializer,
    UserLogin_Serializer,
    UserProfile_Serializer,
    UserProfileUpdate_Serializer,
    UserPasswordChange_Serializer,
    SendPasswordEmail_Serializer,
    UserPasswordReset_Serializer,
    GoogleSignIn_Serializer,
    UserDelete_Serializer,
)
from rest_framework.response import Response
from rest_framework import generics, permissions, status
from django.contrib.auth import authenticate
from eps.utils import Util
from .models import User
from .token_generate import get_tokens_for_user
from eps.permission import IsTeacherUser
import random
import string


# user registration view.
class UserRegistrationView(APIView):
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        serializer = UserRegistration_Serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            user = serializer.save()
            uid = user.id
            is_student = request.data.get("is_student", False)
            print("==========", is_student)
            if is_student == "True":
                unique_number = self.generate_unique_number()
                user.exam_id = unique_number
                user.save()
            # sending the mail to the user after he/she is registred succesfully.
            data = {
                "subject": "Welcome to Our Community!",
                "body": f"Dear {user.first_name},\n\n"
                "Congratulations! You've successfully registered on our platform.\n\n"
                "Best regards,\n"
                "The EPS Team",
                "to_email": user.email,
            }
            Util.send_email(data)
            token = get_tokens_for_user(user)  # for the token...
            return Response(
                {
                    "token": token,
                    "msg": "Registration Successful",
                    "uid": uid,
                },
                status=status.HTTP_201_CREATED,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def generate_unique_number(self):
        letters = string.ascii_uppercase
        number_part = "".join(random.choices(string.digits, k=5))
        letter_part = random.choice(letters)
        return f"{letter_part}{number_part}"


# user login view.
class UserLoginView(APIView):
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        serializer = UserLogin_Serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            email = serializer.data.get("email")
            password = serializer.data.get("password")
            user = authenticate(email=email, password=password)
            print(user)
            if user is not None:
                uid = user.id
                user_type = user.is_admin
                user_student = user.is_student
                user_teacher = user.is_teacher
                user_exam_id = user.exam_id
                # user_fname = user.first_name
                # user_lname = user.last_name
                user_name = user.username

                token = get_tokens_for_user(user)
                return Response(
                    {
                        "token": token,
                        "user_is_admin": user_type,
                        "student": user_student,
                        "teacher": user_teacher,
                        "msg": "Login Successfully",
                        "id": uid,
                        "user_exam_id": user_exam_id,
                        "user_name": user_name,
                    },
                    status=status.HTTP_200_OK,
                )
            else:
                return Response(
                    {"msg": "Email or Password is not valide"},
                    status=status.HTTP_404_NOT_FOUND,
                )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# login user profile view.
class UserProfileView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request, format=None):
        serializer = UserProfile_Serializer(request.user)
        return Response(
            serializer.data,
            status=status.HTTP_200_OK,
        )


# login user profile update view.
class UserProfileUpdateView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAuthenticated]

    def put(self, request, *args, **kwargs):
        user = request.user
        print(user)
        try:
            user_data = User.objects.get(id=user.id)
            print(user_data)
        except User.DoesNotExist:
            return Response(
                {"msg": f"Login user with the id {user.id} doesnt exits"},
                status=status.HTTP_404_NOT_FOUND,
            )
        serializer = UserProfileUpdate_Serializer(
            user_data,
            data=request.data,
            partial=True,
        )
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(
                serializer.data,
                status=status.HTTP_200_OK,
            )

        # return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST,)


# user password change view.
class UserPasswordChangeView(APIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request, format=None):
        serializer = UserPasswordChange_Serializer(
            data=request.data, context={"user": request.user}
        )
        if serializer.is_valid(raise_exception=True):
            return Response(
                {"msg": "Password changed Sucessfully"},
                status=status.HTTP_200_OK,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# sending the email to the user to change the password.
class SendPassowrdEmailView(APIView):
    renderer_classes = [UserRenderer]

    def post(self, request, format=None):
        serializer = SendPasswordEmail_Serializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            return Response(
                {"msg": "Passwoed Reset link send. Please check your Email"},
                status=status.HTTP_200_OK,
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# user password change view through the mail.
class UserPasswordResetView(APIView):
    renderer_classes = [UserRenderer]

    def post(self, request, uid, token, format=None):
        serializer = UserPasswordReset_Serializer(
            data=request.data, context={"uid": uid, "token": token}
        )
        if serializer.is_valid(raise_exception=True):
            return Response({"msg": "Password Reset Sucessfully"})
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# Googe Part
class GoogleSignInApiView(GenericAPIView):
    serializer_class = GoogleSignIn_Serializer

    def post(self, request):
        serializer = self.serializer_class(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = (serializer.validated_data)["access_token"]
        return Response(data, status=status.HTTP_200_OK)


# total user in the site.
class UserApiView(generics.ListAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    # permission_classes = [IsTeacherUser]

    def get(self, request, *args, **kwargs):
        role = kwargs.get("name")

        if role == "all":
            user_data = User.objects.all()
        elif role == "student":
            user_data = User.objects.filter(is_student=True)
        elif role == "teacher":
            user_data = User.objects.filter(is_teacher=True)
        else:
            return Response(
                {"msg": "Invalid role. Please specify 'all', 'student', or 'teacher'."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        serializer = UserProfile_Serializer(user_data, many=True)
        return Response(
            serializer.data,
        )


# user deletion for the admin part.
class UserDeleteApiView(generics.DestroyAPIView):
    renderer_classes = [UserRenderer]
    permission_classes = [permissions.IsAdminUser]
    queryset = User.objects.all()
    serializer_class = UserDelete_Serializer
