# here we are making the google auth.
from google.auth.transport import requests
from google.oauth2 import id_token
from account.models import User
from django.contrib.auth import authenticate
from django.conf import settings
from rest_framework.exceptions import AuthenticationFailed
from .token_generate import get_tokens_for_user
from rest_framework.response import Response
from rest_framework import status
import random
import string
from django.contrib.auth.hashers import make_password
import os


# this will verify if the token is really comming from the google or not.
class Google:
    @staticmethod
    def validate(access_token):
        try:
            id_info = id_token.verify_oauth2_token(access_token, requests.Request())
            if "accounts.google.com" in id_info["iss"]:
                return id_info

        except Exception as e:
            return "token is not valid or expired."


# login user through the google.
def Login_User_Google(email, password):
    login_user = authenticate(email=email, password=password)
    uid = login_user.id
    user_type = login_user.is_admin
    user_student = login_user.is_student
    user_teacher = login_user.is_teacher
    user_exam_id = login_user.exam_id
    user_fname = login_user.first_name
    user_lname = login_user.last_name
    user_name = f"{user_fname} {user_lname}"
    token = get_tokens_for_user(login_user)
    return {
        "token": token,
        "user_is_admin": user_type,
        "student": user_student,
        "teacher": user_teacher,
        "msg": "Login Successfully",
        "id": uid,
        "user_exam_id": user_exam_id,
        "user_name": user_name,
    }


# generating the random and unique exam_id.
def generate_unique_number():
    letters = string.ascii_uppercase
    number_part = "".join(random.choices(string.digits, k=5))
    letter_part = random.choice(letters)
    return f"{letter_part}{number_part}"


# registering the user through the google and saving the data in the database.
def Register_User_Google(provider, email, first_name, last_name, username, photo):
    user = User.objects.filter(email=email)
    if user.exists():
        if provider == user[0].auth_provider:
            result = Login_User_Google(email, settings.SOCIAL_AUTH_PASSWORD)
            return result
        else:
            raise AuthenticationFailed(
                {"msg": f"Please continue your login with {user[0].auth_provider}"}
            )
    else:
        hashed_password = make_password(settings.SOCIAL_AUTH_PASSWORD)
        new_user = {
            "email": email,
            "first_name": first_name,
            "last_name": last_name,
            "password": hashed_password,
            "username": username,
            "photo": photo,
        }
        register_user = User.objects.create(**new_user)
        register_user.auth_provider = provider
        register_user.is_student = "True"
        unique_number = generate_unique_number()
        register_user.exam_id = unique_number
        register_user.save()
        result = Login_User_Google(
            email=register_user.email, password=settings.SOCIAL_AUTH_PASSWORD
        )
        return result
