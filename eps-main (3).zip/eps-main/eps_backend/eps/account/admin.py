from django.contrib import admin
from .models import User


# registering the user model in the admin pannel.
class UserModel_Admin(admin.ModelAdmin):
    list_display = (
        "id",
        "email",
        "first_name",
        "last_name",
        "exam_id",
        "phone",
        "username",
        "is_admin",
        "is_student",
        "is_teacher",
    )


admin.site.register(User, UserModel_Admin)
